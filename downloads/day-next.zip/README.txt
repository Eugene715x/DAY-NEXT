DAY / NEXT — одиночная экспедиция

Откройте day-next.html в браузере. Установка и интернет не нужны.
Клик/касание — идти, перетаскивание — карта, колесо/щипок — масштаб.
Кнопка атласа — реальная/вымышленная карта, импорт OSM/XML/JSON, экспорт JSON.

Реальная местность: Beatty / Rhyolite, Nevada, USA. Исторический снимок OSM 2017-08-18.
Геоданные: © OpenStreetMap contributors, ODbL 1.0
https://www.openstreetmap.org/copyright
Исходники, происхождение данных и конвертер:
https://github.com/Eugene715x/DAY-NEXT
